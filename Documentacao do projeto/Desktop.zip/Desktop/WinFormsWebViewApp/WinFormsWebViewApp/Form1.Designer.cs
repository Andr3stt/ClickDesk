namespace WinFormsWebViewApp
{
    partial class Form1
    {
        private Microsoft.Web.WebView2.WinForms.WebView2 webView;
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            webView = new Microsoft.Web.WebView2.WinForms.WebView2();
            ((System.ComponentModel.ISupportInitialize)webView).BeginInit();
            SuspendLayout();
            // 
            // webView
            // 
            webView.AllowExternalDrop = true;
            webView.CreationProperties = null;
            webView.DefaultBackgroundColor = System.Drawing.Color.White;
            webView.Dock = System.Windows.Forms.DockStyle.Fill;
            webView.Location = new System.Drawing.Point(0, 0);
            webView.Name = "webView";
            webView.Size = new System.Drawing.Size(1008, 704);
            webView.TabIndex = 0;
            webView.ZoomFactor = 1D;
            // 
            // Form1
            // 
            ClientSize = new System.Drawing.Size(1008, 704);
            Controls.Add(webView);
            Name = "Form1";
            Text = "CLICKDESK Desktop";
            ((System.ComponentModel.ISupportInitialize)webView).EndInit();
            ResumeLayout(false);
        }
    }
}
