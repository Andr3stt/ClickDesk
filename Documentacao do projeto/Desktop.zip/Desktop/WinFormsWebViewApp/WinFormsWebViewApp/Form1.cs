using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace WinFormsWebViewApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string caminho = @"C:\Users\vinic\OneDrive\Desktop\ProjetoDesk\ProjetoClick\CLICKDESK - VINI\CLICKDESK - COP\index.html";
            if (!File.Exists(caminho))
            {
                MessageBox.Show("Arquivo não encontrado:\n" + caminho);
                return;
            }
            webView.Source = new Uri(caminho);
        }
    }
}
